/****************************************************************************
 *   $Id:: blinky_main.c 4785 2010-09-03 22:39:27Z nxp21346                        $
 *   Project: LED flashing / ISP test program
 *
 *   Description:
 *     This file contains the main routine for the blinky code sample
 *     which flashes an LED on the LPCXpresso board and also increments an
 *     LED display on the Embedded Artists base board. This project
 *     implements CRP and is useful for testing bootloaders.
 *
 ****************************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
****************************************************************************/

#include "driver_config.h"
#include "target_config.h"

#include "timer32.h"
#include "gpio.h"
#include "uart.h"
#include "type.h"
#include "i2c.h"
#include "IAP.h"
#include "crc.h"
#include "xmodem1k.h"

// =========== variables ============

/* UART variables*/
extern volatile uint32_t UARTCount;
extern volatile uint8_t UARTBuffer[BUFSIZE];

/* I2C variables */

extern volatile uint32_t I2CCount;
extern volatile uint8_t I2CMasterBuffer[BUFSIZE];
extern volatile uint8_t I2CSlaveBuffer[BUFSIZE];
extern volatile uint32_t I2CMasterState;
extern volatile uint32_t I2CReadLength, I2CWriteLength;

/* Flash */

uint16_t FLASHADDRESSSector0 = 0x0000UL;
uint16_t FLASHADDRESSSector1 = 0x1000UL;
uint16_t FLASHADDRESSSector2 = 0x2000UL;
uint16_t FLASHADDRESSSector3 = 0x3000UL;
uint16_t FLASHADDRESSSector4 = 0x4000UL;
uint16_t FLASHADDRESSSector5 = 0x5000UL;
uint16_t FLASHADDRESSSector6 = 0x6000UL;
uint16_t FLASHADDRESSSector7 = 0x7000UL;

#define FLASHADDRESS 0x00004000 //0x0000131C

#define FLASHSECTOR  4


/* Function prototypes */
static void vBootLoader_Task(void);
//static uint32_t u32BootLoader_AppPresent(void);
static uint32_t u32Bootloader_WriteCRC(uint16_t u16CRC);
static uint32_t u32BootLoader_ProgramFlash(uint8_t *pu8Data, uint16_t u16Len);

// =========== Main Program ===========

int main (void)
{
  /* Basic chip initialization is taken care of in SystemInit() called
   * from the startup code. SystemInit() and chip settings are defined
   * in the CMSIS system_<part family>.c file.
   */

// Program variables




// =========== INCLUDE ===========

  /* Initialize 32-bit timer 0. TIME_INTERVAL is defined as 10mS */
  /* You may also want to use the Cortex SysTick timer to do this */
  init_timer32(0, TIME_INTERVAL);

  /* Enable timer 0. Our interrupt handler will begin incrementing
   * the TimeTick global each time timer 0 matches and resets.
   */
  enable_timer32(0);

  /* Initialize GPIO (sets up clock) */
  GPIOInit();

  /* Set LED port pin to output */
  GPIOSetDir( LED_PORT, LED_BIT, 1 ); // onboard LED - Led1
  int led1 = 1;
  GPIOSetDir( 2, 6, 1 ); // extern LED - Led2
  int led2 = 1;

  /* Initialize UART - baudrate*/
  UARTInit(UART_BAUD);

	#if MODEM_TEST
	  ModemInit();
	#endif

	 //I2C Initialize
	if ( I2CInit( (uint32_t)I2CMASTER ) == FALSE )	/* initialize I2c */
	{
		while ( 1 );				/* Fatal error */
	}



	while (1)
	{
	/* Loop forever */

	if ( UARTCount != 0 )
 	{
 		uint8_t uartValue = (uint8_t *)UARTBuffer[0]; // value in uart buffer
 		if(uartValue == '1')
 		{
 			uint8_t T1[4] = {'L','e','d','1'};
 			LPC_UART->IER = IER_THRE | IER_RLS;			/* Disable RBR */
 			UARTSend( (uint8_t *)T1, 4 );
 			UARTCount = 0;
 			LPC_UART->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */

 			if(led1 == 1)
 			{
 				GPIOSetValue( LED_PORT, LED_BIT, LED_OFF );
 				led1 = 0;
 			}
 			else
 			{
 				GPIOSetValue( LED_PORT, LED_BIT, LED_ON );
 				led1 = 1;
 			}
 		}
 		if(uartValue == '2')
		{
			uint8_t T2[5] = {'L','e','d','2'};
			LPC_UART->IER = IER_THRE | IER_RLS;			/* Disable RBR */
			UARTSend( (uint8_t *)T2, 4 );
			UARTCount = 0;
			LPC_UART->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */

			if(led2 == 1)
			{
				GPIOSetValue( 2, 6, LED_OFF );
				led2 = 0;
			}
			else
			{
				GPIOSetValue( 2, 6, LED_ON );
				led2 = 1;
			}
		}
 		else if(uartValue == '3')
 		{
			LPC_UART->IER = IER_THRE | IER_RLS;			/* Disable RBR */
			UARTSend( (uint8_t *)UARTBuffer, UARTCount );
			UARTCount = 0;
			LPC_UART->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */

			if(led2 == 1)
			{
				GPIOSetValue( 2, 6, LED_OFF );
				led2 = 0;
			}
			else
			{
				GPIOSetValue( 2, 6, LED_ON );
				led2 = 1;
			}

			if(led1 == 1)
			{
				GPIOSetValue( LED_PORT, LED_BIT, LED_OFF );
				led1 = 0;
			}
			else
			{
				GPIOSetValue( LED_PORT, LED_BIT, LED_ON );
				led1 = 1;
			}
		}
 		else if(uartValue == '4')
 		{
 			uint8_t resArray[6];

 			for(int i = 0 ; i < 6 ; i++)
 			{
 	 			uint16_t result = *(uint16_t*)(FLASHADDRESS+i+i);
 	 			resArray[i] = result;
 			}


 			LPC_UART->IER = IER_THRE | IER_RLS;			/* Disable RBR */
			UARTSend( (uint8_t *)resArray, 6);
			UARTCount = 0;
			LPC_UART->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */

 		}
 		else if(uartValue == '5')
		{
 			uint16_t testArray[128];

 			for(uint16_t i = 0 ; i < sizeof(testArray)/sizeof(testArray[0]) ; i++)
 			{
 				testArray[i] = 0xFF;
 			}

 			testArray[0] = 'T';
 			testArray[1] = 'H';
 			testArray[2] = 'O';
 			testArray[3] = 'M';
 			testArray[4] = 'A';
 			testArray[5] = 'S';

 			uint8_t res;

 			__disable_irq();

 			if(u32IAP_PrepareSectors(FLASHSECTOR , FLASHSECTOR) == IAP_STA_CMD_SUCCESS) // check 1
 			{
 				GPIOSetValue( 2, 6, LED_ON );
 				if (u32IAP_EraseSectors(FLASHSECTOR, FLASHSECTOR) == IAP_STA_CMD_SUCCESS) // erase sector
 				{
 					GPIOSetValue( LED_PORT, LED_BIT, LED_ON );
 					if (u32IAP_PrepareSectors(FLASHSECTOR, FLASHSECTOR) == IAP_STA_CMD_SUCCESS) // check 2
					{

 						switch(u32IAP_CopyRAMToFlash(FLASHADDRESS,(uint32_t)testArray,IAP_FLASH_PAGE_SIZE_BYTES))
 						{
 						case 0:
							res = '0';
							break;
 						case 1:
 							res = '1';
 							break;
 						case 2:
 							res = '2';
 							break;
 						case 3:
							res = '3';
							break;
 						case 4:
							res = '4';
							break;
 						case 5:
							res = '5';
							break;
 						case 6:
							res = '6';
							break;
 						case 7:
							res = '7';
							break;
 						case 8:
							res = '8';
							break;
 						case 9:
							res = '9';
							break;
 						case 10:
							res = 'A';
							break;
 						case 11:
							res = 'B';
							break;
 						case 12:
							res = 'C';
							break;
 						}
					}
 				}
 			}

 			  __enable_irq();

 			 uint8_t T3[1] ;
 			 T3[0] = res;

 			 LPC_UART->IER = IER_THRE | IER_RLS;			/* Disable RBR */
 			 UARTSend( (uint8_t *)T3, 1 );
 			 UARTCount = 0;
 			 LPC_UART->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */
		}
 		else if(uartValue == '6')
		{
 			/* Valid application not present, execute bootloader task that will
 					   obtain a new application and program it to flash.. */
 					vBootLoader_Task();

 					/* Above function only returns when new application image has been
 					   successfully programmed into flash. Begin execution of this new
 					   application by resetting the device. */
 					NVIC_SystemReset();
		}
 		else if(uartValue == '7')
 		{
 			uint8_t resArray[3];
			uint8_t spacers[2] = {' ','_'};
			uint8_t symb[2] = {0xA,0xD};
			uint8_t pageNr = 0;
			uint8_t pageArray[7] = {'P','A','G','E','_','0','0'};
			uint8_t sectorArray[8] = {'S','E','C','T','O','R','_','X'};

			for(uint8_t m = 0 ; m < 8 ; m++)
			{
				sectorArray[7] = m + '0';

				LPC_UART->IER = IER_THRE | IER_RLS;			/* Disable RBR */
				UARTSend( (uint8_t *)symb, 1);
				UARTSend( (uint8_t *)symb, 2);
				UARTSend( (uint8_t *)sectorArray, 8);
				UARTSend( (uint8_t *)symb, 2);
				UARTCount = 0;
				LPC_UART->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */



				for(uint8_t i = 0; i < 16 ; i++) // changed from 16
				{
					// page number
					pageNr = i;

					if(pageNr > 9)
					{
						pageArray[5] = '1';
						pageArray[6] = pageNr - 10 + '0';
					}
					else
					{
						pageArray[5] = '0';
						pageArray[6] = pageNr + '0';
					}

					LPC_UART->IER = IER_THRE | IER_RLS;			/* Disable RBR */
					UARTSend( (uint8_t *)symb, 1);
					UARTSend( (uint8_t *)symb, 2);
					UARTSend( (uint8_t *)pageArray, 7);
					UARTSend( (uint8_t *)symb, 2);
					UARTCount = 0;
					LPC_UART->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */

					uint16_t test;
					switch(m)
					{
						case 0:
							test = FLASHADDRESSSector0;
							break;
						case 1:
							test = FLASHADDRESSSector1;
							break;
						case 2:
							test = FLASHADDRESSSector2;
							break;
						case 3:
							test = FLASHADDRESSSector3;
							break;
						case 4:
							test = FLASHADDRESSSector4;
							break;
						case 5:
							test = FLASHADDRESSSector5;
							break;
						case 6:
							test = FLASHADDRESSSector6;
							break;
						case 7:
							test = FLASHADDRESSSector7;
							break;
					}

					// sector based print of flash

					for(uint8_t n = 0 ; n < 255 ; n++) // changed from 255
					{
						uint16_t result = *(uint16_t*)(test + (pageNr * 256) + n + n );
						charToHex(result, resArray);

						LPC_UART->IER = IER_THRE | IER_RLS;			/* Disable RBR */
						UARTSend( (uint8_t *)resArray, 3);
						UARTSend( (uint8_t *)spacers, 1);
						UARTCount = 0;
						LPC_UART->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */
					}
				}
			}
 		}
 		else
 		{
 			LPC_UART->IER = IER_THRE | IER_RLS;			/* Disable RBR */
 			UARTSend( (uint8_t *)UARTBuffer, UARTCount );
 			UARTCount = 0;
 			LPC_UART->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */
 		}
 	}
 	}
}


/* Functions */

/*****************************************************************************
 ** Function name:	u32BootLoader_ProgramFlash
 **
 ** Description:
 **
 ** Parameters:	    None
 **
 ** Returned value: 0 if programming failed, otherwise 1.
 **
 *****************************************************************************/
static uint32_t u32BootLoader_ProgramFlash(uint8_t *pu8Data, uint16_t u16Len)
{
	uint32_t u32Result = 0;

	static uint32_t u32NextFlashWriteAddr = APP_START_ADDR;

	if ((pu8Data != 0) && (u16Len != 0))
	{
		/* Prepare the flash application sectors for reprogramming */
		if (u32IAP_PrepareSectors(APP_START_SECTOR, APP_END_SECTOR) == IAP_STA_CMD_SUCCESS)
		{
			/* Ensure that amount of data written to flash is at minimum the
			   size of a flash page */
			if (u16Len < IAP_FLASH_PAGE_SIZE_BYTES)
			{
				u16Len = IAP_FLASH_PAGE_SIZE_BYTES;
			}

			/* Write the data to flash */
			if (u32IAP_CopyRAMToFlash(u32NextFlashWriteAddr, (uint32_t)pu8Data, u16Len) == IAP_STA_CMD_SUCCESS)
			{
				/* Check that the write was successful */
				if (u32IAP_Compare(u32NextFlashWriteAddr, (uint32_t)pu8Data, u16Len, 0) == IAP_STA_CMD_SUCCESS)
				{
					/* Write was successful */
					u32NextFlashWriteAddr += u16Len;
					u32Result = 1;
				}
			}
		}
	}
	return (u32Result);
}

/*****************************************************************************
 ** Function name:	u32Bootloader_WriteCRC
 **
 ** Description:	Writes a 16-bit CRC value to the last location in flash
 ** 				memory, the bootloader uses this value to check for a valid
 ** 				application at startup.
 **
 ** Parameters:	    u16CRC - CRC value to be written to flash
 **
 ** Returned value: 1 if CRC written to flash successfully, otherwise 0.
 **
 *****************************************************************************/
static uint32_t u32Bootloader_WriteCRC(uint16_t u16CRC)
{
	uint32_t i;
	uint32_t u32Result = 0;
	uint32_t a32DummyData[IAP_FLASH_PAGE_SIZE_WORDS];
	uint32_t *pu32Mem = (uint32_t *)(APP_END_ADDR - IAP_FLASH_PAGE_SIZE_BYTES);

	/* First copy the data that is currently present in the last page of
	   flash into a temporary buffer */
	for (i = 0 ; i < IAP_FLASH_PAGE_SIZE_WORDS; i++)
	{
		a32DummyData[i] = *pu32Mem++;
	}

	/* Set the CRC value to be written back */
	a32DummyData[IAP_FLASH_PAGE_SIZE_WORDS - 1] = (uint32_t)u16CRC;

	if (u32IAP_PrepareSectors(APP_END_SECTOR, APP_END_SECTOR) == IAP_STA_CMD_SUCCESS)
	{
		/* Now write the data back, only the CRC bits have changed */
		if (u32IAP_CopyRAMToFlash((APP_END_ADDR - IAP_FLASH_PAGE_SIZE_BYTES),
				                  (uint32_t)a32DummyData,
				                  IAP_FLASH_PAGE_SIZE_BYTES) == IAP_STA_CMD_SUCCESS)
		{
			u32Result = 1;
		}
	}
	return (u32Result);
}

/*****************************************************************************
 ** Function name:  vBootLoader_Task
 **
 ** Description:	Erases application flash area and starts XMODEM client so
 ** 				that new application can be downloaded.
 **
 ** Parameters:	    None
 **
 ** Returned value: None
 **
 *****************************************************************************/
static void vBootLoader_Task(void)
{
	/* Erase the application flash area so it is ready to be reprogrammed with the new application */
	if (u32IAP_PrepareSectors(APP_START_SECTOR, APP_END_SECTOR) == IAP_STA_CMD_SUCCESS)
	{
		if (u32IAP_EraseSectors(APP_START_SECTOR, APP_END_SECTOR) == IAP_STA_CMD_SUCCESS)
		{
			uint16_t u16CRC = 0;

			/* Start the xmodem client, this function only returns when a
			   transfer is complete. Pass it pointer to function that will
			   handle received data packets */
			vXmodem1k_Client(&u32BootLoader_ProgramFlash);

			/* Programming is now complete, calculate the CRC of the flash image */
			u16CRC = u16CRC_Calc16((const uint8_t *)APP_START_ADDR, (APP_END_ADDR - APP_START_ADDR - 4));

			/* Write the CRC value into the last 16-bit location of flash, this
			   will be used to check for a valid application at startup  */
			(void)u32Bootloader_WriteCRC(u16CRC);
		}
	}
}


char hexDigit(unsigned n)
{
    if (n < 10) {
        return n + '0';
    } else {
        return (n - 10) + 'A';
    }
}

void charToHex(char c, char hex[3])
{
    hex[0] = hexDigit(c / 0x10);
    hex[1] = hexDigit(c % 0x10);
    hex[2] = '\0';
}
