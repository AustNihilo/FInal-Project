//flash access commands using IAP functions

// Flash locations and sectors
#define IAP_LOCATION 0x03000205
#define FLASHADDRESS 0x0003FF00
#define FLASHSECTOR  7

