invokeisp
=====================
Demonstrates how to put the LPC part into bootloader mode from your
program. This could be serial, CAN, or USB bootloader mode depending
on which LPC part is being used and how it is connected.
